# Fresh Vegetable Android
Android WebView app for https://fresh-vegetable-kolkata.netlify.app with WhatsApp deep-link handling.
